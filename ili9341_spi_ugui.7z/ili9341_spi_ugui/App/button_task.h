#ifndef __BUTTON_TASK_H__
#define __BUTTON_TASK_H__

#ifdef __cplusplus  
extern "C" {  
#endif  
	
#include "stm32f4xx_hal.h"	
	
extern uint8_t manual_auto_status;	
	
	
void button_task_init(void);	
void button_task_check(void);
	
	
#ifdef __cplusplus
} 
#endif

#endif
