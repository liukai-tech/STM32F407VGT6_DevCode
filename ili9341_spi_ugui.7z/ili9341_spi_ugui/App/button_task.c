#include "includes.h"

uint8_t manual_auto_status = 0;

volatile uint8_t button_check_ticks = 0;

#define BTN_AUTO_PORT       	GPIOE
#define BTN_AUTO_PIN        	GPIO_PIN_14
#define BTN_UP_PORT         	GPIOE
#define BTN_UP_PIN          	GPIO_PIN_13
#define BTN_DOWN_PORT         	GPIOE
#define BTN_DOWN_PIN          	GPIO_PIN_12
#define BTN_CONFIG_PORT         GPIOE
#define BTN_CONFIG_PIN          GPIO_PIN_11
#define BTN_ENTER_PORT         	GPIOE
#define BTN_ENTER_PIN          	GPIO_PIN_10

/* define button vaild level */
#ifndef KEY_ON
#define KEY_ON      0
#endif

static struct Button btnAuto;
static struct Button btnUp;
static struct Button btnDown;
static struct Button btnConfig;
static struct Button btnEnter;

static uint8_t button_auto_read_pin(void)
{
    return HAL_GPIO_ReadPin(BTN_AUTO_PORT, BTN_AUTO_PIN);
}

static uint8_t button_up_read_pin(void)
{
    return HAL_GPIO_ReadPin(BTN_UP_PORT, BTN_UP_PIN);
}

static uint8_t button_down_read_pin(void)
{
    return HAL_GPIO_ReadPin(BTN_DOWN_PORT, BTN_DOWN_PIN);
}

static uint8_t button_config_read_pin(void)
{
    return HAL_GPIO_ReadPin(BTN_CONFIG_PORT, BTN_CONFIG_PIN);
}

static uint8_t button_enter_read_pin(void)
{
    return HAL_GPIO_ReadPin(BTN_ENTER_PORT, BTN_ENTER_PIN);
}

void button_auto_callback(void *btn)
{
    uint32_t btn_event_val;

    btn_event_val = get_button_event((struct Button *)btn);

    switch(btn_event_val)
    {
    case PRESS_DOWN:
        printf("button_auto press down\r\n");
    break;

    case PRESS_UP:
        printf("button_auto press up\r\n");
    break;

    case PRESS_REPEAT:
        printf("button_auto press repeat\r\n");
    break;

    case SINGLE_CLICK:
        printf("button_auto single click\r\n");
        if(manual_auto_status){
            manual_auto_status = 0;
        }else{
            manual_auto_status = 1;
        }
    break;

    case DOUBLE_CLICK:
        printf("button_auto double click\r\n");
    break;

    case LONG_PRESS_START:
        printf("button_auto long press start\r\n");
    break;

    case LONG_PRESS_HOLD:
        printf("button_auto long press hold\r\n");
    break;
    }
}

void button_up_callback(void *btn)
{
    uint32_t btn_event_val;

    btn_event_val = get_button_event((struct Button *)btn);

    switch(btn_event_val)
    {
    case PRESS_DOWN:
        printf("button_up press down\r\n");
    break;

    case PRESS_UP:
        printf("button_up press up\r\n");
    break;

    case PRESS_REPEAT:
        printf("button_up press repeat\r\n");
    break;

    case SINGLE_CLICK:
        printf("button_up single click\r\n");
    break;

    case DOUBLE_CLICK:
        printf("button_up double click\r\n");
    break;

    case LONG_PRESS_START:
        printf("button_up long press start\r\n");
    break;

    case LONG_PRESS_HOLD:
        printf("button_up long press hold\r\n");
    break;
    }
}

void button_down_callback(void *btn)
{
    uint32_t btn_event_val;

    btn_event_val = get_button_event((struct Button *)btn);

    switch(btn_event_val)
    {
    case PRESS_DOWN:
        printf("button_down press down\r\n");
    break;

    case PRESS_UP:
        printf("button_down press up\r\n");
    break;

    case PRESS_REPEAT:
        printf("button_down press repeat\r\n");
    break;

    case SINGLE_CLICK:
        printf("button_down single click\r\n");
    break;

    case DOUBLE_CLICK:
        printf("button_down double click\r\n");
    break;

    case LONG_PRESS_START:
        printf("button_down long press start\r\n");
    break;

    case LONG_PRESS_HOLD:
        printf("button_down long press hold\r\n");
    break;
    }
}

void button_config_callback(void *btn)
{
    uint32_t btn_event_val;

    btn_event_val = get_button_event((struct Button *)btn);

    switch(btn_event_val)
    {
    case PRESS_DOWN:
        printf("button_config press down\r\n");
    break;

    case PRESS_UP:
        printf("button_config press up\r\n");
    break;

    case PRESS_REPEAT:
        printf("button_config press repeat\r\n");
    break;

    case SINGLE_CLICK:
        printf("button_config single click\r\n");
    break;

    case DOUBLE_CLICK:
        printf("button_config double click\r\n");
    break;

    case LONG_PRESS_START:
        printf("button_config long press start\r\n");
    break;

    case LONG_PRESS_HOLD:
        printf("button_config long press hold\r\n");
    break;
    }
}

void button_enter_callback(void *btn)
{
    uint32_t btn_event_val;

    btn_event_val = get_button_event((struct Button *)btn);

    switch(btn_event_val)
    {
    case PRESS_DOWN:
        printf("button_enter press down\r\n");
    break;

    case PRESS_UP:
        printf("button_enter press up\r\n");
    break;

    case PRESS_REPEAT:
        printf("button_enter press repeat\r\n");
    break;

    case SINGLE_CLICK:
        printf("button_enter single click\r\n");
    break;

    case DOUBLE_CLICK:
        printf("button_enter double click\r\n");
    break;

    case LONG_PRESS_START:
        printf("button_enter long press start\r\n");
    break;

    case LONG_PRESS_HOLD:
        printf("button_enter long press hold\r\n");
    break;
    }
}

void button_task_init(void)
{
    button_init  (&btnAuto, button_auto_read_pin, KEY_ON);
    button_attach(&btnAuto, PRESS_DOWN,       button_auto_callback);
    button_attach(&btnAuto, PRESS_UP,         button_auto_callback);
    button_attach(&btnAuto, PRESS_REPEAT,     button_auto_callback);
    button_attach(&btnAuto, SINGLE_CLICK,     button_auto_callback);
    button_attach(&btnAuto, DOUBLE_CLICK,     button_auto_callback);
    button_attach(&btnAuto, LONG_PRESS_START, button_auto_callback);
    button_attach(&btnAuto, LONG_PRESS_HOLD,  button_auto_callback);
    button_start (&btnAuto);

    button_init  (&btnUp, button_up_read_pin, KEY_ON);
    button_attach(&btnUp, PRESS_DOWN,       button_up_callback);
    button_attach(&btnUp, PRESS_UP,         button_up_callback);
    button_attach(&btnUp, PRESS_REPEAT,     button_up_callback);
    button_attach(&btnUp, SINGLE_CLICK,     button_up_callback);
    button_attach(&btnUp, DOUBLE_CLICK,     button_up_callback);
    button_attach(&btnUp, LONG_PRESS_START, button_up_callback);
    button_attach(&btnUp, LONG_PRESS_HOLD,  button_up_callback);
    button_start (&btnUp);

    button_init  (&btnDown, button_down_read_pin, KEY_ON);
    button_attach(&btnDown, PRESS_DOWN,       button_down_callback);
    button_attach(&btnDown, PRESS_UP,         button_down_callback);
    button_attach(&btnDown, PRESS_REPEAT,     button_down_callback);
    button_attach(&btnDown, SINGLE_CLICK,     button_down_callback);
    button_attach(&btnDown, DOUBLE_CLICK,     button_down_callback);
    button_attach(&btnDown, LONG_PRESS_START, button_down_callback);
    button_attach(&btnDown, LONG_PRESS_HOLD,  button_down_callback);
    button_start (&btnDown);

    button_init  (&btnConfig, button_config_read_pin, KEY_ON);
    button_attach(&btnConfig, PRESS_DOWN,       button_config_callback);
    button_attach(&btnConfig, PRESS_UP,         button_config_callback);
    button_attach(&btnConfig, PRESS_REPEAT,     button_config_callback);
    button_attach(&btnConfig, SINGLE_CLICK,     button_config_callback);
    button_attach(&btnConfig, DOUBLE_CLICK,     button_config_callback);
    button_attach(&btnConfig, LONG_PRESS_START, button_config_callback);
    button_attach(&btnConfig, LONG_PRESS_HOLD,  button_config_callback);
    button_start (&btnConfig);

    button_init  (&btnEnter, button_enter_read_pin, KEY_ON);
    button_attach(&btnEnter, PRESS_DOWN,       button_enter_callback);
    button_attach(&btnEnter, PRESS_UP,         button_enter_callback);
    button_attach(&btnEnter, PRESS_REPEAT,     button_enter_callback);
    button_attach(&btnEnter, SINGLE_CLICK,     button_enter_callback);
    button_attach(&btnEnter, DOUBLE_CLICK,     button_enter_callback);
    button_attach(&btnEnter, LONG_PRESS_START, button_enter_callback);
    button_attach(&btnEnter, LONG_PRESS_HOLD,  button_enter_callback);
    button_start (&btnEnter);
}

void button_task_check(void)
{
	if(++button_check_ticks >= 5)
	{
		button_check_ticks = 0;
		button_ticks();
	}
}

