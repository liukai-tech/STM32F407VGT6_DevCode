#ifndef __DISPLAY_TASK_H__
#define __DISPLAY_TASK_H__

#ifdef __cplusplus  
extern "C" {  
#endif  
	
#include "stm32f4xx_hal.h"	
		
	
void display_task_init(void);	
void uGUI_GNSS_Init(void);
void uGUI_GNSS_Test(void);

	
#ifdef __cplusplus
} 
#endif

#endif
