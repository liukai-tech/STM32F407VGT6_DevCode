// ------------------------------------
// �GUI example project
// http://www.embeddedlightning.com/
// ------------------------------------


#ifndef __SYSTEM_H
#define __SYSTEM_H

#include "stm32f4xx_hal.h"
#include "stdint.h"
#include "ugui.h"
#include <stdio.h>
#include <math.h>
#include <stdlib.h>


#endif
