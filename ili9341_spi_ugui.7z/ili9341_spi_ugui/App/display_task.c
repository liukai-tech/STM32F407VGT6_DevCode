#include "includes.h"

/* GUI structure */
UG_GUI gui;
uint8_t gui_is_init = 0;

void pset(UG_S16 x, UG_S16 y, UG_COLOR col)
{
   ILI9341_DrawPixel(x, y ,col);
}

/* Hardware accelerator for UG_DrawLine (Platform: STM32F4x9) */
UG_RESULT _HW_DrawLine( UG_S16 x1, UG_S16 y1, UG_S16 x2, UG_S16 y2, UG_COLOR c )
{
	ILI9341_DrawLine(x1, y1, x2, y2, c);
	return UG_RESULT_OK;
}

/* Hardware accelerator for UG_FillFrame (Platform: STM32F4x9) */
UG_RESULT _HW_FillFrame( UG_S16 x1, UG_S16 y1, UG_S16 x2, UG_S16 y2, UG_COLOR c )
{
	ILI9341_Fill(x1, y1, x2 - x1, y2 - y1, c);
	return UG_RESULT_OK;
}

void uGUI_GNSS_Init(void)
{
	/* Init ��GUI */
	UG_Init(&gui, (void(*)(UG_S16,UG_S16,UG_COLOR))pset, ILI9341_WIDTH, ILI9341_HEIGHT);
	
//	/* Register hardware acceleration */
	UG_DriverRegister( DRIVER_DRAW_LINE, (void*)_HW_DrawLine );
	UG_DriverRegister( DRIVER_FILL_FRAME, (void*)_HW_FillFrame );
	UG_DriverEnable( DRIVER_DRAW_LINE );
	UG_DriverEnable( DRIVER_FILL_FRAME );
	
	UG_FillScreen( C_BLACK );
	
	ILI9341_Fill_Color(ILI9341_BLACK);
	
	UG_SetForecolor(C_RED);
	UG_FontSelect(&FONT_8X12);	
	UG_PutString(100,70,"abcdABCD");
	
	ILI9341_WriteString(100, 50, "Hello World.", Font_11x18, ILI9341_GBLUE, ILI9341_BLACK);
	
	ILI9341_ShowChinese(20, 20, 0, 16, ILI9341_GREEN, ILI9341_BLACK);
	ILI9341_ShowChinese(20+16+2, 20, 1, 16, ILI9341_GREEN, ILI9341_BLACK);
	ILI9341_ShowChinese(20+16+2+16+2, 20, 2, 16, ILI9341_GREEN, ILI9341_BLACK);
	ILI9341_ShowChinese(20+16+2+16+2+16+2, 20, 3, 16, ILI9341_GREEN, ILI9341_BLACK);
	ILI9341_ShowChinese(20+16+2+16+2+16+2+16+2, 20, 4, 16, ILI9341_GREEN, ILI9341_BLACK);
	ILI9341_ShowChinese(20+16+2+16+2+16+2+16+2+16+2, 20, 5, 16, ILI9341_GREEN, ILI9341_BLACK);
	
	ILI9341_ShowGBK(20, 50, 16, (uint8_t *)"�й�����", ILI9341_RED, ILI9341_BLACK);
	
	ILI9341_ShowGBK(20, 100, 24, (uint8_t *)"�����翴���й�����", ILI9341_BLUE, ILI9341_BLACK);
	
	ILI9341_ShowGBK(20, 150, 32, (uint8_t *)"����ƽ��ϵͳ", ILI9341_YELLOW, ILI9341_BLACK);
	
	HAL_Delay(2000);
	
	UG_FillScreen(C_BLACK);
}

/* ʱ��ṹ�� */
typedef struct _RUNTIME
{
    uint16_t     day;        /**< Days since midnight - [0,65535] */
    uint16_t     hour;       /**< Hours since midnight - [0,65535] */
    uint16_t     min;        /**< Minutes after the hour - [0,59] */
    uint16_t     sec;        /**< Seconds after the minute - [0,59] */

} runtime;

/* ������ʱ����ת������ */
#define     TIME_SS     1000
#define     TIME_MI     60000
#define     TIME_HH     3600000
#define     TIME_DD     86400000

runtime runtime_t = {0,0,0,0};

/**
  * @brief  MsConvertTime
  * @note   ����ת��Ϊʱ����
  * @param  time_t��ʱ��ṹ��
  * @retval ��
  */
void MsConvertTime(uint64_t ms, runtime * time_t)
{
    time_t->day = ms / TIME_DD;
    time_t->hour = (ms - time_t->day * TIME_DD) / TIME_HH;
    time_t->min = (ms - time_t->day * TIME_DD - time_t->hour * TIME_HH) / TIME_MI;
    time_t->sec = (ms - time_t->day * TIME_DD - time_t->hour * TIME_HH - time_t->min * TIME_MI) / TIME_SS;
}

/* better rand() function */
UG_U32 randx( void )
{
   static UG_U32 z1 = 12345, z2 = 12345, z3 = 12345, z4 = 12345;
   UG_U32 b;
   b  = ((z1 << 6) ^ z1) >> 13;
   z1 = ((z1 & 4294967294U) << 18) ^ b;
   b  = ((z2 << 2) ^ z2) >> 27;
   z2 = ((z2 & 4294967288U) << 2) ^ b;
   b  = ((z3 << 13) ^ z3) >> 21;
   z3 = ((z3 & 4294967280U) << 7) ^ b;
   b  = ((z4 << 3) ^ z4) >> 12;
   z4 = ((z4 & 4294967168U) << 13) ^ b;
   return (z1 ^ z2 ^ z3 ^ z4);
}

void uGUI_GNSS_Test(void)
{	
	char formatbuf[32] = {0};
	uint8_t len = 0;
	static uint32_t ticks_pre = 0; 	
	static uint8_t toggle_flag = 0;
	
	
//	UG_SetBackcolor(C_BLACK);	
//	UG_SetForecolor(C_LIGHT_GREEN);	
//	UG_FontSelect(&FONT_10X16);	
//	UG_PutString(0,0,"Fixed");
	
	ILI9341_ShowGBK(0, 0, 24, (uint8_t *)"�̶�", C_LIGHT_GREEN, C_BLACK);
    
	UG_SetForecolor(C_WHITE);	
	UG_FontSelect(&FONT_12X20);	
	UG_PutString(0 + 24*2 + 12, 5, "25");
	
	UG_SetForecolor(C_LIGHT_CORAL);	
	UG_FontSelect(&FONT_12X20);	
	UG_PutString(0 + 24*2 + 12 + 12*2 + 12, 5,"1.0");
	
	UG_FillFrame(0,  24 + 2, ILI9341_WIDTH - 1, 24 + 4, C_SEA_GREEN);
	
	UG_SetForecolor(C_ORANGE);	
	UG_FontSelect(&FONT_10X16);	
	UG_PutString(0,35,"22.0215m");
	
	/* ����߲� */
	int hgt = randx() % 10;
	if(hgt % 2){
		hgt *= -1;
		len = snprintf(formatbuf, 32, "%d", hgt);
		
#if 0
		ILI9341_DrawImage(ILI9341_WIDTH - 64 - 1, 40, 64, 64, (uint16_t *)arrow_up_64x64_1);
#endif		
		
		ILI9341_DrawFilledTriangle(ILI9341_WIDTH - 64 - 1, 40, ILI9341_WIDTH - 1, 40, ILI9341_WIDTH - 32 - 1, 40 + 64, ILI9341_GRAY);
		ILI9341_Fill(ILI9341_WIDTH - 63 + 2, 40 + 64 + 1, 60, 24, ILI9341_GRAY);
		ILI9341_DrawFilledTriangle(ILI9341_WIDTH - 64 - 1, 40 + 64 + 24 + 2 + 64, ILI9341_WIDTH - 1, 40 + 64 + 24 + 2 + 64, ILI9341_WIDTH - 32 - 1, 40 + 64 + 24 + 2, ILI9341_YELLOW);
		
		
	}else{
		if(hgt == 0){
			len = snprintf(formatbuf, 32, " %d", hgt);
#if 0			
			ILI9341_Fill(ILI9341_WIDTH - 64 - 1, 40, 64, 64, ILI9341_BLACK);
			ILI9341_Fill(ILI9341_WIDTH - 64 - 1, 40 + 20, 64, 24, ILI9341_GREEN);
#endif
			ILI9341_DrawFilledTriangle(ILI9341_WIDTH - 64 - 1, 40, ILI9341_WIDTH - 1, 40, ILI9341_WIDTH - 32 - 1, 40 + 64, ILI9341_GRAY);
			ILI9341_Fill(ILI9341_WIDTH - 63 + 2, 40 + 64 + 1, 60, 24, ILI9341_GREEN);
			ILI9341_DrawFilledTriangle(ILI9341_WIDTH - 64 - 1, 40 + 64 + 24 + 2 + 64, ILI9341_WIDTH - 1, 40 + 64 + 24 + 2 + 64, ILI9341_WIDTH - 32 - 1, 40 + 64 + 24 + 2, ILI9341_GRAY);
		
			
		}else{
			len = snprintf(formatbuf, 32, "+%d", hgt);
#if 0			
			ILI9341_DrawImage(ILI9341_WIDTH - 64 - 1, 40, 64, 64, (uint16_t *)arrow_down_64x64_1);
#endif		

			ILI9341_DrawFilledTriangle(ILI9341_WIDTH - 64 - 1, 40, ILI9341_WIDTH - 1, 40, ILI9341_WIDTH - 32 - 1, 40 + 64, ILI9341_RED);
			ILI9341_Fill(ILI9341_WIDTH - 63 + 2, 40 + 64 + 1, 60, 24, ILI9341_GRAY);
			ILI9341_DrawFilledTriangle(ILI9341_WIDTH - 64 - 1, 40 + 64 + 24 + 2 + 64, ILI9341_WIDTH - 1, 40 + 64 + 24 + 2 + 64, ILI9341_WIDTH - 32 - 1, 40 + 64 + 24 + 2, ILI9341_GRAY);
			
		}		
	}	
	formatbuf[len] = '\0';
	UG_SetBackcolor(C_BLACK);
	UG_SetForecolor(C_RED);
	UG_FontSelect(&FONT_64X107);	
//	UG_PutString(ILI9341_WIDTH/2 - 64, ILI9341_HEIGHT/2 - 64,formatbuf);
	UG_PutString(0 + 64, ILI9341_HEIGHT/2 - 64,formatbuf);
	
//	UG_SetBackcolor(C_BLACK);
//	UG_SetForecolor(C_GREEN);	
//	UG_FontSelect(&FONT_10X16);	
//	UG_PutString(0,ILI9341_HEIGHT - 16 -1,"Auto");
	
	ILI9341_ShowGBK(0,ILI9341_HEIGHT - 32 -1, 32, (uint8_t *)"����", C_YELLOW, C_BLACK);
	
	/* ����ʱ�� */
	uint32_t ticks = HAL_GetTick();
	MsConvertTime(ticks, &runtime_t);
	len = snprintf(formatbuf, 32, "%02d:%02d:%02d", runtime_t.hour, runtime_t.min, runtime_t.sec);
	formatbuf[len] = '\0';
	
	UG_SetBackcolor(C_BLACK);
	UG_SetForecolor(C_LIGHT_SKY_BLUE);	
	UG_FontSelect(&FONT_12X20);	
	UG_PutString(ILI9341_WIDTH - 110, 5,formatbuf);
	
//	UG_SetBackcolor(C_BLACK);
//	UG_SetForecolor(C_SALMON);	
//	UG_FontSelect(&FONT_10X16);	
//	UG_PutString(ILI9341_WIDTH - 60, ILI9341_HEIGHT - 16 -1,"Horiz");

	UG_FillFrame(0,  ILI9341_HEIGHT - 32 - 4, ILI9341_WIDTH - 1, ILI9341_HEIGHT - 32 - 2, C_SEA_GREEN);

	ILI9341_ShowGBK(ILI9341_WIDTH - 32*2, ILI9341_HEIGHT - 32 -1, 32, (uint8_t *)"ˮƽ", C_SALMON, C_BLACK);
	
	if(manual_auto_status){
		ILI9341_ShowGBK(0 + 32*2 + 20 + 32*2 +20, ILI9341_HEIGHT - 32 -1, 32, (uint8_t *)"�Զ�", C_GREEN, C_BLACK);
	}else{
		ILI9341_ShowGBK(0 + 32*2 + 20 + 32*2 +20, ILI9341_HEIGHT - 32 -1, 32, (uint8_t *)"�ֶ�", C_RED, C_BLACK);
	}
	
	
	
	if(HAL_GetTick() - ticks_pre > 500)
	{
		ticks_pre = HAL_GetTick();
		if(toggle_flag){
			toggle_flag = 0;
		}else{
			toggle_flag = 1;
		}
	}
	
	if(toggle_flag){
		ILI9341_ShowGBK(0 + 32*2 + 20, ILI9341_HEIGHT - 32 -1, 32, (uint8_t *)"ƫ��", C_LIGHT_SEA_GREEN, C_BLACK);
	}else{
		ILI9341_ShowGBK(0 + 32*2 + 20, ILI9341_HEIGHT - 32 -1, 32, (uint8_t *)"ƫ��", C_ORANGE, C_BLACK);
	}
	
}
