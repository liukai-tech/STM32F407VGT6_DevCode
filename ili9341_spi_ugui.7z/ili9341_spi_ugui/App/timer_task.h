#ifndef __TIMER_TASK_H__
#define __TIMER_TASK_H__

#ifdef __cplusplus  
extern "C" {  
#endif  
	
#include "stm32f4xx_hal.h"	
	
	
	
void timer_task_init(void);	
	
	
#ifdef __cplusplus
} 
#endif

#endif
