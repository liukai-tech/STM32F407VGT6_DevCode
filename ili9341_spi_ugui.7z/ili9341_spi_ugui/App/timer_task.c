#include "includes.h"

extern void uGUI_GNSS_Test(void);


struct Timer timer1;
struct Timer timer2;

void timer1_callback(void)
{
    printf("-%u- timer1 timeout\r\n", HAL_GetTick());
	timer_start(&timer1);
//	sys_led_toggle();
}

void timer2_callback(void)
{
    printf("-%u- timer2 timeout\r\n", HAL_GetTick());
	timer_start(&timer2);
	uGUI_GNSS_Test();	
}


void timer_task_init(void)
{
	timer_init(&timer1, timer1_callback, 1000, 1000); //1s loop
    timer_start(&timer1);
    
    timer_init(&timer2, timer2_callback, 50, 0); //50ms delay
    timer_start(&timer2);
}


