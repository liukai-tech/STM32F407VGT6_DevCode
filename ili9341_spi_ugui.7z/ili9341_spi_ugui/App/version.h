/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-10-26     sunnav22       the first version
 */
#ifndef _VERSION_H_
#define _VERSION_H_

//#define DEBUG_VERSION       //debug version mode
#define RELEASED_VERSION    //released version mode


#if defined(DEBUG_VERSION)
    #define APP_VERSION_MODE    "Debug"
#elif defined(RELEASED_VERSION)
    #define APP_VERSION_MODE    "Released"
#endif

#define PRODUCT_TYPE_NUMBER "GNSS Land Controller"
#define MODEL_TYPE_NUMBER "GC200"
#define APP_VERSION "1.0.0"
#define LICENCE_DEF "Copyright (C) 2020 SunNav Technology Co.,Ltd. All rights reserved."
#define DESIGN_DEF "Designed by Caesar <792910363@qq.com>."

void PrintAppVersionInfo(void);

#endif /* _VERSION_H_ */

