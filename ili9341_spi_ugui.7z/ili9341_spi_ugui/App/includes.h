#ifndef __INCLUDES_H__
#define __INCLUDES_H__

#ifdef __cplusplus  
extern "C" {  
#endif  
	
#include "stm32f4xx_hal.h"	
#include "main.h"
#include "spi.h"
#include "usart.h"
#include "gpio.h"
	
#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include "ili9341.h"
#include "fonts.h"
//#include "testimg.h"

/* uGUI */
#include "ugui_config.h"
//#include "image.h"
#include "system.h"

#include "version.h"

#include "multi_timer.h"
#include "timer_task.h"

#include "button_task.h"
#include "multi_button.h"

#include "display_task.h"
	
#ifdef __cplusplus
} 
#endif

#endif
