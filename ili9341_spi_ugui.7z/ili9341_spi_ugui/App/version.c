/*
 * Copyright (c) 2006-2020, Caesar
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2021-01-16     Caesar       the first version
 */

#include "version.h"

/* print app version info */
void PrintAppVersionInfo(void)
{
    printf("%s\r\n", PRODUCT_TYPE_NUMBER);
    printf("Model:%s\r\n", MODEL_TYPE_NUMBER);
    printf("Version:%s %s\r\n", APP_VERSION, APP_VERSION_MODE);
    printf("Build %s %s\r\n", __TIME__, __DATE__);
    printf("%s\r\n", LICENCE_DEF);
    printf("%s\r\n", DESIGN_DEF);
}
